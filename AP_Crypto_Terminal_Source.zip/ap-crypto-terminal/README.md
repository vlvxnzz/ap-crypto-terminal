# AP Crypto Terminal

A responsive, dark neon crypto-market monitoring dashboard inspired by the supplied reference image. Built with React, TypeScript, and Vite.

## Included

- Live public spot ticker, one-minute (or selected timeframe) candles, and partial order-book depth from Binance public endpoints.
- Responsive SVG candlestick chart, volume histogram, market snapshot panels, and order-book display.
- Neon activity visualization and sample trader card inspired by the reference. These elements are explicitly marked as decorative/demo data.
- Connection status, reconnect behavior, pause/resume feed, asset and timeframe selectors, and an event log.
- No account login, exchange API keys, wallet connection, private keys, order execution, or automated trading.

## Requirements

- macOS, Windows, or Linux
- Node.js 20+ recommended (includes npm)
- Internet connection for public Binance market data and Google Fonts

## Run on your Mac

1. Install Node.js LTS from https://nodejs.org/ if you do not already have it.
2. Unzip this project, then open Terminal.
3. Move into the project folder. Example if it is in Downloads:

   ```bash
   cd ~/Downloads/ap-crypto-terminal
   ```

4. Install dependencies:

   ```bash
   npm install
   ```

5. Start the development server:

   ```bash
   npm run dev
   ```

6. Open the local URL Vite prints, usually `http://localhost:5173`.

To create a production build:

```bash
npm run build
npm run preview
```

## Data and transparency

- Price, ticker percentage change, candles, and order-book levels are sourced from Binance's public spot-market API/WebSocket. This is not an exchange account connection; availability depends on network access and Binance service availability in your region.
- The leaderboard, profile balance, win-rate, streak, and activity particles are illustrative mock UI only. They are not connected to a real trader and must not be interpreted as actual performance.
- The event log reports feed/system events only. No order requests are sent.
- The chart uses a small custom SVG renderer to keep the project easy to understand and modify without a charting dependency.

## Project layout

```text
ap-crypto-terminal/
├── index.html
├── package.json
├── tsconfig.json
├── tsconfig.app.json
├── vite.config.ts
├── README.md
└── src/
    ├── App.tsx       # Dashboard, WebSocket feed, chart, panels
    ├── main.tsx      # React entry point
    └── styles.css    # Responsive neon terminal theme
```

## Next upgrades

- Persist user preferences locally (without storing secrets).
- Add selectable exchange data adapters and a provider-health panel.
- Add configurable price alerts using browser notifications.
- Add a read-only portfolio tracker using carefully scoped API keys only if needed. Never enter seed phrases or private keys into this project.
- Add tests and a backend only if you need multi-device synchronization or server-side alert delivery.

## Disclaimer

This project is educational software for market observation. It does not provide financial advice, guarantee data accuracy, or execute trades. Always verify prices and risk independently.
